import os
import logging
import time
import requests

class Helper:
    def check_missed_var(required_var_list, target_input):
        missed_var_list = []
        for v in required_var_list:
            if v not in target_input:
                missed_var_list.append(v)
        return missed_var_list

class Faz:
    def __init__(self):
        self.logger = logging.getLogger("lambda")
        self.logger.setLevel(logging.INFO)
        self.faz_ip = os.getenv("faz_username")
        self.faz_username = os.getenv("faz_username")
        self.faz_password = os.getenv("faz_password")
        self.faz_adom = os.getenv("faz_adom")
        self.faz_login_port = "" if os.getenv("faz_login_port_number") == "" else ":" + os.getenv("faz_login_port_number")
        self.return_json = {
            'ErrorMsg': None,
            'ResponseContent': None
        }

    def main(self, event):
        self.logger.info(f"Start lambda function for FortiAnalyzer configuration service.")
        self.logger.info(f"Event content: {event}") # Internal test
        operation = event["operation"]
        parameters = event["parameters"]
        if operation == "authorize_device":
            missed_var_list = Helper.check_missed_var(["fgt_ip", "fgt_name", "fgt_sn"], parameters)
            if missed_var_list:
                self.return_json['ErrorMsg'] = "Could not find parameter: " + ", ".join(missed_var_list) + "."
                return
            b_succ = self.authorize_device(parameters)
            if not b_succ:
                self.return_json['ErrorMsg'] = "Could not authorize device."
                return
        elif operation == "remove_device":
            missed_var_list = Helper.check_missed_var(["fgt_name"], parameters)
            if missed_var_list:
                self.return_json['ErrorMsg'] = "Could not find parameter: " + ", ".join(missed_var_list) + "."
                return
            b_succ = self.remove_device(parameters)
            if not b_succ:
                self.return_json['ErrorMsg'] = "Could not remove device."
                return
        else:
            self.return_json['ErrorMsg'] = f"Unknown operation {operation}."
            return
        
    def authorize_device(self, parameters):
        self.logger.info("Authorize FortiGate on FortiAnalyzer by HTTP.")
        session = self.login()
        if not session:
            self.logger.error(f"Could not http connect to FortiAnalyzer {self.faz_ip}")
            self.return_json['ErrorMsg'] = f"Could not http connect to FortiAnalyzer {self.faz_ip}"
            return False
        url = f"https://{self.faz_ip}{self.faz_login_port}/jsonrpc"
        header = {
            "Content-Type": "application/json"
        }
        body = {
            "method": "exec",
            "params": [
                {
                    "data": {
                        "adom": self.faz_adom,
                        "device": {
                            "adm_pass": [self.faz_password],
                            "adm_usr": self.faz_username,
                            "device action": "promote_unreg",
                            "ip": parameters["fgt_ip"],
                            "name": parameters["fgt_name"],
                            "sn": parameters["fgt_sn"]
                        }
                    },
                    "url": "/dvm/cmd/add/device"
                }
            ],
            "session": session,
            "verbose": 1
        }
        self.logger.info(f"HTTP request url: {url}.") # Internal test
        self.logger.info(f"HTTP request header: {header}.") # Internal test
        self.logger.info(f"HTTP request body: {body}.") # Internal test
        response = requests.post(url, headers=header, json=body, verify=False, timeout=20)
        return_status = False
        if response.status_code == 200:
            response_json = response.json()
            https_status = None
            if response_json and "result" in response_json and response_json["result"]:
                rst = response_json["result"][0]
                if "status" in rst and "code" in rst["status"]:
                    https_status = rst["status"]["code"]
                    if https_status == 0:
                        return_status = True
                    else:
                        msg = rst["status"]["message"]
                        self.logger.error(f"Authorize FortiGate failed: {msg}")
            if https_status == None:
                self.logger.info("Could not get http return status")
        self.logger.info(f"HTTP request response: {response}.") # Internal test
        response.close()
        self.logout(session)
        return return_status
    
    def remove_device(self, parameters):
        self.logger.info("Remove FortiGate on FortiAnalyzer by HTTP.")
        session = self.login()
        if not session:
            self.logger.error(f"Could not http connect to FortiAnalyzer {self.faz_ip}")
            self.return_json['ErrorMsg'] = f"Could not http connect to FortiAnalyzer {self.faz_ip}"
            return False
        url = f"https://{self.faz_ip}{self.faz_login_port}/jsonrpc"
        header = {
            "Content-Type": "application/json"
        }
        body = {
            "method": "exec",
            "params": [
                {
                    "data": {
                        "adom": self.faz_adom,
                        "device": parameters["fgt_name"]
                    },
                    "url": "/dvm/cmd/add/device"
                }
            ],
            "session": session,
            "verbose": 1
        }
        self.logger.info(f"HTTP request url: {url}.") # Internal test
        self.logger.info(f"HTTP request header: {header}.") # Internal test
        self.logger.info(f"HTTP request body: {body}.") # Internal test
        response = requests.post(url, headers=header, json=body, verify=False, timeout=20)
        return_status = False
        if response.status_code == 200:
            response_json = response.json()
            https_status = None
            if response_json and "result" in response_json and response_json["result"]:
                rst = response_json["result"][0]
                if "status" in rst and "code" in rst["status"]:
                    https_status = rst["status"]["code"]
                    if https_status == 0:
                        return_status = True
                    else:
                        msg = rst["status"]["message"]
                        self.logger.error(f"Authorize FortiGate failed: {msg}")
            if https_status == None:
                self.logger.info("Could not get http return status")
        self.logger.info(f"HTTP request response: {response}.") # Internal test
        response.close()
        self.logout(session)
        return return_status
    

    def login(self, max_loop=10):
        self.logger.info("Login to FortiAnalyzer instance and get session.")
        self.logger.info(f"fazip: {self.faz_ip}") # Internal test
        url = f"https://{self.faz_ip}{self.faz_login_port}/jsonrpc"
        header = {
            "Content-Type": "application/json"
        }
        body = {
            "id": 1,
            "method": "exec",
            "params": [
                {
                    "data": {
                        "passwd": self.faz_password,
                        "user": self.faz_username
                    },
                    "url": "/sys/login/user"
                }
            ]
        }
        self.logger.info(f"HTTP request url: {url}.") # Internal test
        self.logger.info(f"HTTP request body: {body}.") # Internal test
        for i in range(max_loop):
            if i > 0:
                self.logger.info(f"Sleep {i} 30 sec.")
                time.sleep(30)
            try:
                response = requests.post(url, headers=header, json=body, verify=False, timeout=20)
                if response.status_code == 200:
                    response_json = response.json()
                    if response_json and "session" in response_json:
                        session = response_json["session"]
                        if session:
                            return session
                else:
                    self.logger.info("Could not get session")
                # response.close()
            except Exception as err:
                self.logger.info(f"Could not get http return status, try again. Error: {err}")
        return ""
    
    def logout(self, session):
        self.logger.info("Logout FortiAnalyzer session.")
        self.logger.info(f"fazip: {self.faz_ip}") # Internal test
        url = f"https://{self.faz_ip}{self.faz_login_port}/jsonrpc"
        header = {
            "Content-Type": "application/json"
        }
        body = {
            "id": 1,
            "method": "exec",
            "params": [
                {
                    "url": "/sys/logout"
                }
            ],
            "session": session
        }
        self.logger.info(f"HTTP request url: {url}.") # Internal test
        self.logger.info(f"HTTP request body: {body}.") # Internal test
        response = requests.post(url, headers=header, json=body, verify=False, timeout=20)
        return_status = False
        if response.status_code == 200:
            response_json = response.json()
            https_status = None
            if response_json and "result" in response_json and response_json["result"]:
                rst = response_json["result"][0]
                if "status" in rst and "code" in rst["status"]:
                    https_status = rst["status"]["code"]
                    if https_status == 0:
                        return_status = True
                    else:
                        msg = rst["status"]["message"]
                        self.logger.error(f"Authorize FortiGate failed: {msg}")
            if https_status == None:
                self.logger.info("Could not get http return status")
        self.logger.info(f"HTTP request response: {response}.") # Internal test
        response.close()
        return return_status
    
def lambda_handler(event, context):
    service = event["service"]
    response = None
    ## FortiGate configuration operations
    if service == "faz":
        fazObject = Faz()
        fazObject.main(event)
        response = fazObject.return_json
    else:
        response = {
            'ErrorMsg': f"Unknown service: {service}.",
            'ResponseContent': None
        }
    return response


